"""
insight.py — arXivSub Insight (pivot) API client
Bundled with arxivsub-insight skill.

Builds custom pivot statistics over the arXivSub corpora — the same engine as the
website's Custom Chart — and writes the result to ./tmp/arxivsub_insight.json.

The API key is read from the ARXIVSUB_SKILL_KEY environment variable or a .env
file in the current directory. Never pass it as a command-line argument.

Usage (called by Claude via bash_tool):
    python3 insight.py --corpus arxiv --dim time:month --measure count_papers --breakdown keyword --filters '{"keywords":["Large Language Model"]}'
    python3 insight.py --corpus arxiv --dim affiliation --measure count_papers --filters '{"search":"reinforcement learning"}' --options '{"top_n_dim":15}'
    python3 insight.py --corpus ciiina --dim time:year --measure count_papers --breakdown conference
"""

import argparse
import json
import os
import sys
import urllib.request
import urllib.error

API_URL = "https://qtevnmgyobilaanrzidq.supabase.co/functions/v1/agent-skills-gateway"


def load_api_key() -> str:
    """Read API key from environment or .env file. Exit with setup instructions if missing."""
    key = os.environ.get("ARXIVSUB_SKILL_KEY", "").strip()
    if key:
        return key

    # Fallback: parse a .env file in the current directory
    env_file = os.path.join(os.getcwd(), ".env")
    if os.path.isfile(env_file):
        with open(env_file) as f:
            for line in f:
                line = line.strip()
                if line.startswith("ARXIVSUB_SKILL_KEY="):
                    key = line.split("=", 1)[1].strip().strip('"').strip("'")
                    if key:
                        return key

    sys.stderr.write(
        "ARXIVSUB_SKILL_KEY is not set.\n"
        "Set it up using one of these methods:\n"
        "  1. Export as an environment variable:\n"
        "       export ARXIVSUB_SKILL_KEY=your_key_here\n"
        "  2. Add it to a .env file in your working directory:\n"
        "       ARXIVSUB_SKILL_KEY=your_key_here\n"
        "Your API key can be found on the Skills page of the arXivSub website.\n"
    )
    sys.exit(1)


def _parse_json_arg(raw, label):
    """Parse a --filters/--options JSON-object argument; exit cleanly on bad input."""
    if raw is None:
        return {}
    try:
        val = json.loads(raw)
    except json.JSONDecodeError as e:
        sys.stderr.write(f"--{label} must be valid JSON: {e}\n")
        sys.exit(1)
    if not isinstance(val, dict):
        sys.stderr.write(f"--{label} must be a JSON object.\n")
        sys.exit(1)
    return val


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--corpus", default="arxiv", choices=["arxiv", "ciiina", "conference"])
    parser.add_argument("--dim", required=True,
                        help="axis: time:day|week|month|year, keyword, category, conference, award, affiliation, author, citation_bin")
    parser.add_argument("--measure", default="count_papers",
                        help="count_papers|count_authors|count_affiliations|count_keywords|avg_citation|median_citation|award_rate")
    parser.add_argument("--breakdown", default=None, help="optional second dim, same value set as --dim")
    parser.add_argument("--filters", default=None,
                        help="JSON object: search/start_date/end_date/keywords/categories/conferences/publish_years/awards/affiliations")
    parser.add_argument("--options", default=None,
                        help="JSON object: top_n_dim/top_n_breakdown/min_count/show_others/sort")
    parser.add_argument("--style", default=None,
                        help="how YOU will render it (bar|bar_h|line|area|pie|heatmap|treemap|wordcloud|table); not sent to the API")
    args = parser.parse_args()

    api_key = load_api_key()

    body = {
        "action": "insight",
        "corpus": args.corpus,
        "dim": args.dim,
        "measure": args.measure,
        "breakdown": args.breakdown,
        "filters": _parse_json_arg(args.filters, "filters"),
        "options": _parse_json_arg(args.options, "options"),
    }

    payload = json.dumps(body).encode("utf-8")
    headers = {
        "Content-Type": "application/json",
        "x-agent-skill-key": api_key,
    }

    req = urllib.request.Request(API_URL, data=payload, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req) as resp:
            raw = resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
        error_body = e.read().decode("utf-8")
        sys.stderr.write(f"HTTP {e.code}: {error_body}\n")
        sys.exit(1)
    except urllib.error.URLError as e:
        sys.stderr.write(f"Request failed: {e.reason}\n")
        sys.exit(1)

    data = json.loads(raw)

    out_dir = os.path.join(os.getcwd(), "tmp")
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "arxivsub_insight.json")
    with open(out_path, "w") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    rows = data.get("rows", [])
    quota = data.get("quota_remaining")
    style = args.style or "(choose based on dim)"
    print(f"row_count={len(rows) if isinstance(rows, list) else 'n/a'}, "
          f"quota_remaining={quota}, style={style}, output={out_path}")


if __name__ == "__main__":
    main()
