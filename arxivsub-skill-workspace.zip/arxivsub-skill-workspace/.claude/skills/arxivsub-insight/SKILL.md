---
name: arxivsub-insight
description: >
  Research analytics assistant — builds custom pivot charts over arXiv and top AI/CV conference
  papers (CVPR, ICCV, ECCV, ICLR, ICML, NeurIPS, AAAI, MICCAI, CoRL, RSS, ACL, EMNLP, ICRA, IROS, IJCAI) via the arXivSub Insight API. Use whenever
  the user asks about trends, statistics, rankings, breakdowns or comparisons of the literature —
  e.g. "how has interest in diffusion models trended", "top institutions in reinforcement learning",
  "papers per month broken down by keyword", "which conferences publish the most multimodal work",
  "avg citations by affiliation". It exposes the SAME pivot engine as the website's Custom Chart:
  pick a corpus, an axis (dim), a measure, an optional breakdown, plus filters and options. For
  finding or reading specific papers, use the arxivsub-skill (search) skill instead.
---

# arxivsub-insight

Build aggregate "pivot" statistics over the arXivSub corpora — the same engine as the website's
Custom Chart. You choose **what goes on the axis (`dim`)**, **what to measure (`measure`)**, and
optionally **how to split it (`breakdown`)**, plus filters and options. One bundled script does it:
`scripts/insight.py`.

---

## Language Rule

**Always respond in the same language the user is using.**

---

## Step 0: Authentication

The API key is read automatically by `insight.py` from the environment — never ask the user for it and never pass it as a CLI argument.

If `insight.py` exits with a non-zero code mentioning `ARXIVSUB_SKILL_KEY`, tell the user (in their language) to set it up via **one** of these methods:

1. Export as a shell environment variable (add to `~/.zshrc` or `~/.bashrc` for persistence):
   ```
   export ARXIVSUB_SKILL_KEY=your_key_here
   ```
2. Add to a `.env` file in the working directory:
   ```
   ARXIVSUB_SKILL_KEY=your_key_here
   ```

This is the **same key** used by the arxivsub-skill, found on the Skills page of the arXivSub website. **The Insight API requires a Pro subscription (or active free-trial days)** — if the script reports `Pro subscription required`, tell the user to upgrade.

---

## Step 1: Design the pivot query

Translate the user's question into these fields (only `--dim` is required):

**`--corpus`** — `arxiv` (recent arXiv papers, default) or `ciiina` (top AI/CV conference papers; `conference` is accepted as an alias).

**`--dim`** — the axis; what each returned row represents. Valid values:
- arxiv: `time:day`, `time:week`, `time:month`, `time:year`, `keyword`, `category`, `affiliation`, `author`, `citation_bin`
- ciiina: `time:year`, `keyword`, `conference`, `award`, `affiliation`, `author`, `citation_bin`

**`--measure`** — what to compute per row (default `count_papers`). Valid values:
- both corpora: `count_papers`, `count_authors`, `count_affiliations`, `count_keywords`, `avg_citation`, `median_citation`
- ciiina only: `award_rate`

`avg_citation` and `median_citation` aggregate each paper's **last-author total (lifetime) citation count** — NOT per-paper citations. So values are large (tens of thousands and up), and a single famous last author inflates a cell. When using them, always pair with `min_count` (e.g. 30) and a `top_n_dim` to keep cells meaningful, and read the `affiliation`/`author` axis with care — a few rows can be unsplit multi-affiliation strings or `Others`/`Unknown` buckets.

**`--breakdown`** — optional second split (same value set as `--dim`, or omit). E.g. `--dim time:month --breakdown keyword` gives one series per keyword.

**`--filters`** — optional JSON object to narrow the data:
- `search` (full-text), `start_date`, `end_date` (YYYY-MM-DD)
- `keywords` (array of tracked keyword names, e.g. ["Large Language Model","Diffusion model"])
- `categories` (arxiv only); `conferences` / `publish_years` / `awards` (ciiina only); `affiliations`

**`--options`** — optional JSON object: `top_n_dim`, `top_n_breakdown`, `min_count`, `show_others` (bool), `sort` (`measure_desc`|`measure_asc`|`dim_asc`|`dim_desc`).

**`--style`** — how YOU will render it (the API returns rows; you draw the chart): `bar`, `bar_h`, `line`, `area`, `pie`, `heatmap`, `treemap`, `wordcloud`, `table`. Sensible defaults: a `time:*` dim → `line` (or `area` with a breakdown); a categorical dim → `bar`/`bar_h`. Constraints: `pie` only without a breakdown; `heatmap` requires a breakdown; `wordcloud` only for a single non-time dim.

Show the interpreted plan in one line (in the user's language) before calling:

> Pivot: corpus=`arxiv`, dim=`time:month`, measure=`count_papers`, breakdown=`keyword`, filters=`{keywords:[LLM, Diffusion model]}`, style=`area`

---

## Step 2: Run insight.py

```bash
python3 <SKILL_DIR>/scripts/insight.py \
  --corpus arxiv \
  --dim time:month \
  --measure count_papers \
  --breakdown keyword \
  --filters '{"keywords":["Large Language Model","Diffusion model"]}' \
  --options '{"top_n_breakdown":10,"show_others":true}' \
  --style area
```

More examples:

```bash
# Top institutions in reinforcement learning (full-text filter)
python3 <SKILL_DIR>/scripts/insight.py --corpus arxiv --dim affiliation --measure count_papers \
  --filters '{"search":"reinforcement learning"}' --options '{"top_n_dim":15}' --style bar_h

# Avg citation by author for conferences, last 2 years
python3 <SKILL_DIR>/scripts/insight.py --corpus ciiina --dim author --measure avg_citation \
  --filters '{"publish_years":[2025,2026]}' --options '{"top_n_dim":20}' --style bar_h

# Papers per year, broken down by conference
python3 <SKILL_DIR>/scripts/insight.py --corpus ciiina --dim time:year --measure count_papers \
  --breakdown conference --style area
```

The script calls the API and writes the result to `./tmp/arxivsub_insight.json`. It prints `row_count` and `quota_remaining` to stdout.

---

## Step 3: Read the result, visualize, and respond

Read `./tmp/arxivsub_insight.json`. The `rows` field is a list of `{dim, breakdown, value}` — exactly the data behind a Custom Chart. Interpret it and answer the user's question directly:

- Lead with the headline finding (top item, overall trend, biggest gap).
- For a `time:*` dim, describe the shape over time and call out peaks/inflections.
- For a categorical dim, give the ranking and notable gaps.

**Always include a visualization, rendered in the `--style` you chose:**

- If you can produce images, write and run a short matplotlib/plotting script that reads `./tmp/arxivsub_insight.json` and saves a PNG to `./tmp/` (line/area for time dims, horizontal/vertical bars for rankings, pie for shares, heatmap for dim×breakdown), then present the figure.
- If image output is not available, render a compact inline ASCII chart (sparkline/line for time, horizontal bars for rankings) in your reply.
- A `breakdown` becomes the series / stack / legend; respect `top_n_*` so the chart stays readable.

**Never mention files, scripts, or internal mechanics.**

At the bottom, show quota in the user's language as subscript:
English: `Daily quota remaining: N queries` / Chinese: `当日剩余额度：N 次`

---

## Key Rules

- Only `--dim` is required. `--measure` defaults to `count_papers`; everything else is optional.
- Respect corpus validity: `category` is arxiv-only as a named axis; `conference` / `award` dims, `publish_years` / `awards` filters, and the `award_rate` measure are ciiina-only. An invalid dim/measure for the corpus returns an `error` — read it and fix the field, do not retry blindly.
- `--filters` and `--options` are JSON objects; pass them as single-quoted JSON strings.
- `keywords` in filters must be tracked keyword names (e.g. "Large Language Model"); for arbitrary free text use the `search` filter instead.
- `avg_citation` / `median_citation` measure each paper's last-author lifetime citation count (large, outlier-prone numbers, not per-paper) — pair them with `min_count` and `top_n_dim`, and don't read a single huge cell as "this lab is most cited".
- If `insight.py` exits non-zero or stderr contains an error, classify and handle it:
  - **Retryable** (network timeout, temporary server error): inform the user and offer to retry automatically.
  - **Needs user intervention**:
    - `Quota exceeded` → daily quota used up, no retry.
    - `Pro subscription required` → tell the user Insight needs a Pro subscription or trial days, and give them the upgrade link https://arxivsub.comfyai.app/pricing
    - Auth failure / missing key → direct to Step 0 setup.
    - An `error` about the dim/measure → fix the field for that corpus and try once more.
    - Empty rows → widen the window/filters or try the other corpus.
- Never output raw JSON or expose internal mechanics.