"""
library.py — arXivSub personal-library client (save / list)
Bundled with arxivsub-library skill.

Lets an agent manage the user's arXivSub library through the same
agent-skills-gateway used by search/insight (same ARXIVSUB_SKILL_KEY).

Two actions:
  save   — save a paper/conference item; optionally set a note, a reading
           status, and/or add it to a (auto-created) collection.
  list   — return the user's collections + saved items (optionally filtered).

NOTE: there is intentionally NO delete/remove action. Removing saved items or
collections must be done by the user on the arXivSub website.

The API key is read from the ARXIVSUB_SKILL_KEY environment variable or a .env
file in the current directory. Never pass it as a command-line argument.

Usage (called by the agent via bash):
    # Save a paper you found via arxivsub-skill search (source 'arxiv' -> type 'paper')
    python3 library.py save --type paper  --id <uuid> --note "why it matters" --status reading --collection "LLM safety"
    # Save a conference paper (search source 'conferences' -> type 'ciiina')
    python3 library.py save --type ciiina --id <uuid> --collection "CVPR to read"
    # List everything (or filter)
    python3 library.py list
    python3 library.py list --status reading --type paper --collection "LLM safety"
"""

import argparse
import json
import os
import sys
import urllib.request
import urllib.error

API_URL = "https://qtevnmgyobilaanrzidq.supabase.co/functions/v1/agent-skills-gateway"


def load_api_key() -> str:
    """Read API key from environment or .env file. Exit with setup instructions if missing."""
    key = os.environ.get("ARXIVSUB_SKILL_KEY", "").strip()
    if key:
        return key
    env_file = os.path.join(os.getcwd(), ".env")
    if os.path.isfile(env_file):
        with open(env_file) as f:
            for line in f:
                line = line.strip()
                if line.startswith("ARXIVSUB_SKILL_KEY="):
                    key = line.split("=", 1)[1].strip().strip('"').strip("'")
                    if key:
                        return key
    sys.stderr.write(
        "ARXIVSUB_SKILL_KEY is not set.\n"
        "Set it up using one of these methods:\n"
        "  1. export ARXIVSUB_SKILL_KEY=your_key_here\n"
        "  2. add ARXIVSUB_SKILL_KEY=your_key_here to a .env file in the working directory\n"
        "Your API key can be found on the Skills page of the arXivSub website.\n"
    )
    sys.exit(1)


def call_gateway(body: dict, api_key: str) -> dict:
    payload = json.dumps(body).encode("utf-8")
    headers = {"Content-Type": "application/json", "x-agent-skill-key": api_key}
    req = urllib.request.Request(API_URL, data=payload, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        sys.stderr.write(f"HTTP {e.code}: {e.read().decode('utf-8')}\n")
        sys.exit(1)
    except urllib.error.URLError as e:
        sys.stderr.write(f"Request failed: {e.reason}\n")
        sys.exit(1)


def main():
    parser = argparse.ArgumentParser(description="arXivSub personal library client")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_save = sub.add_parser("save", help="save an item (optionally note/status/collection)")
    p_save.add_argument("--type", required=True, choices=["paper", "ciiina"],
                        help="paper (arXiv) or ciiina (conference). From search: source 'arxiv'->paper, 'conferences'->ciiina")
    p_save.add_argument("--id", required=True, help="the item's arXivSub id (uuid), from a prior search result")
    p_save.add_argument("--note", default=None, help="optional note (<=2000 chars)")
    p_save.add_argument("--status", default=None, choices=["unread", "reading", "read"])
    p_save.add_argument("--collection", default=None, help="collection/folder name; created if it doesn't exist")

    p_list = sub.add_parser("list", help="list collections + saved items")
    p_list.add_argument("--status", default=None, choices=["unread", "reading", "read"])
    p_list.add_argument("--type", default=None, choices=["paper", "ciiina"])
    p_list.add_argument("--collection", default=None, help="only items in this collection")
    p_list.add_argument("--limit", type=int, default=100)

    args = parser.parse_args()
    api_key = load_api_key()

    if args.cmd == "save":
        body = {
            "action": "library_save",
            "item_type": args.type,
            "item_id": args.id,
            "note": args.note,
            "reading_status": args.status,
            "collection_name": args.collection,
        }
    else:  # list
        body = {
            "action": "library_list",
            "status": args.status,
            "item_type": args.type,
            "collection_name": args.collection,
            "limit": args.limit,
        }

    data = call_gateway(body, api_key)

    if isinstance(data, dict) and data.get("ok") is False:
        sys.stderr.write(f"{data.get('error', 'request failed')}\n")
        sys.exit(1)

    print(json.dumps(data, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
