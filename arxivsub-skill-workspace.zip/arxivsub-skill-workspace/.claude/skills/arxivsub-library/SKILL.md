---
name: arxivsub-library
description: >
  Manage the user's personal arXivSub library. Use this skill whenever the user wants to
  SAVE / bookmark a paper they found, add a note to a saved paper, mark a paper's reading
  status (unread / reading / read), organize papers into a named collection/folder, or ask
  "what have I saved", "show my library", "which papers are in my <name> collection",
  "what am I currently reading". Trigger on phrasings like "save this", "bookmark that paper",
  "add it to my <X> folder", "note that ...", "mark as read", "list my saved papers".
  For FINDING papers use the arxivsub-skill (search) skill first; for trends/stats use arxivsub-insight.
---

# arxivsub-library

Save papers to, and read, the user's personal arXivSub library via the arXivSub API. One bundled
script: `scripts/library.py` with two subcommands — `save` and `list`.

**This skill can add and update, but NOT delete.** Removing a saved paper or a collection must be
done by the user on the arXivSub website — if the user asks to delete/remove/unsave, tell them so
(in their language) and do not attempt it.

---

## Language Rule

**Always respond in the same language the user is using.**

---

## Step 0: Authentication

The API key is read automatically by `library.py` from the environment — never ask the user for it
and never pass it as a CLI argument. It is the **same `ARXIVSUB_SKILL_KEY`** used by arxivsub-skill
(search) and arxivsub-insight.

If `library.py` exits non-zero mentioning `ARXIVSUB_SKILL_KEY`, tell the user (in their language) to set it via **one** of:

1. `export ARXIVSUB_SKILL_KEY=your_key_here`  (add to `~/.zshrc` / `~/.bashrc` to persist)
2. add `ARXIVSUB_SKILL_KEY=your_key_here` to a `.env` file in the working directory

Their key is on the Skills page of the arXivSub website.

---

## Saving a paper

You need the item's **type** and **id**:
- These come from a prior **arxivsub-skill** search result. In that result, a paper's `source`
  maps to type: `source: "arxiv"` → `--type paper`; `source: "conferences"` → `--type ciiina`.
  Use the paper's `id` field as `--id`.
- If the user says "save this one" about a paper you just showed, reuse that paper's id/source —
  do NOT re-search unless you don't have it.

```bash
python3 <SKILL_DIR>/scripts/library.py save \
  --type paper \
  --id <uuid-from-search> \
  --note "one-line why it matters (optional, <=2000 chars)" \
  --status reading \
  --collection "LLM safety"
```

- `--note`, `--status` (`unread`|`reading`|`read`), `--collection` are all optional.
- `--collection` names a folder; it is **created automatically** if it doesn't exist yet.
- Saving is **idempotent**: saving the same paper again updates the fields you pass (a field you
  omit is left unchanged) and adds it to the collection you name — it never duplicates.
- The JSON reply includes `was_new` (true if newly saved), the resolved `reading_status`, and the
  `collection` it was added to. Confirm to the user in one short sentence (e.g. "Saved to *LLM safety*,
  marked as reading.").

To just add a note or change status on an already-saved paper, call `save` with the same
`--type`/`--id` and only the field you want to change.

---

## Listing the library

```bash
python3 <SKILL_DIR>/scripts/library.py list                       # everything
python3 <SKILL_DIR>/scripts/library.py list --status reading      # only "reading"
python3 <SKILL_DIR>/scripts/library.py list --type ciiina         # only conference papers
python3 <SKILL_DIR>/scripts/library.py list --collection "LLM safety"
```

The reply is `{ total_saved, collections:[{name, item_count, ...}], items:[{title, item_type, item_id,
note, reading_status, conference_name, pdf_url, collections:[...] }] }`. Summarize it for the user:
lead with the count, group by collection or status if useful, and list titles (with status/note when
relevant). **Never dump raw JSON or mention scripts/files.**

---

## Key Rules

- `--type` is `paper` (arXiv) or `ciiina` (conference), derived from the search result's `source`.
- Never invent an `id`; it must come from a real search result (or a previous list). If you don't
  have one, run an arxivsub-skill search first.
- **No deletion**: if asked to remove/unsave/delete, tell the user to do it on the arXivSub website.
- If `library.py` exits non-zero, read stderr and classify:
  - `... not found` → the id/type was wrong; re-check the search result (source→type) or re-search.
  - Auth failure / missing key → Step 0 setup.
  - Network/temporary server error → inform the user and offer to retry.
  - Pro subscription required (HTTP 403) → managing the library via the agent needs Pro or active trial days; give the user the upgrade link: https://arxivsub.comfyai.app/pricing
- Keep confirmations to one short sentence; don't expose internal mechanics.
